// config.js
module.exports = {
  'secret': '123superbatgrey'
};
